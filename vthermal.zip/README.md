# V-Thermal Fast Charging for RN7P(violet)
This module optimizes the threshold values of charge throttling to give you faster charging speeds. Only for Xiaomi Redmi Note 7 Pro(violet).
  
## Requirements
- A device with Qualcomm Snapdragon chipset based.
- Rooted with Magisk and Magisk Manager installed.

## Changelog
#### Version 1.0
- Initial release

## Links
- [XDA Thread](https://forum.xda-developers.com/redmi-note-7-pro/themes/magisk-thermal-fast-charging-rn7p-t3999439)
